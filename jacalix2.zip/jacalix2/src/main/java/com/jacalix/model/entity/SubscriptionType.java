package com.jacalix.model.entity;

public enum SubscriptionType {

	BASIC,ADVANCED,GOLD;
}
