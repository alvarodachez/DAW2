package com.jacalix.model.entity;

public enum Category {

	FILM,SERIE,DOCUMENTARY
}
